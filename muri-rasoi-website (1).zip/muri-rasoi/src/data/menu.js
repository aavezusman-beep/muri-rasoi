// ---------------------------------------------------------------------------
// MENU DATA
// ---------------------------------------------------------------------------
// Edit this file to add real menu items and prices once you have them.
// `price: null` means "not yet added" — the UI shows "Ask your server" or a
// price is simply hidden rather than displaying a made-up number.
//
// `image` should point to a filename inside /public/images/. If the file
// doesn't exist yet, the site automatically falls back to a placeholder
// block, so you can add real dish photos whenever you have them.
// ---------------------------------------------------------------------------

export const categories = [
  'Indian',
  'Chinese',
  'Starters',
  'Main Course',
  'Vegetarian',
  'Non-Vegetarian',
  'Rice & Biryani',
  'Drinks',
]

export const menuItems = [
  {
    name: 'Chicken Biryani',
    category: 'Rice & Biryani',
    price: null,
    description: 'A customer favourite — called out by name in our Google reviews.',
    image: 'dish-chicken-biryani.jpg',
    tag: 'Popular Pick',
  },
  {
    name: "Chef's Special Chinese",
    category: 'Chinese',
    price: null,
    description: 'A house favourite from our Chinese menu.',
    image: 'dish-chinese-special.jpg',
    tag: 'Chinese Favourite',
  },
  {
    name: 'Chef\'s Special Indian Thali',
    category: 'Indian',
    price: null,
    description: 'A well-rounded plate from our Indian kitchen.',
    image: 'dish-indian-thali.jpg',
    tag: "Chef's Special",
  },
  {
    name: 'Grilled Special',
    category: 'Starters',
    price: null,
    description: 'Freshly grilled, packed with flavour.',
    image: 'dish-grilled-special.jpg',
    tag: 'Grilled Special',
  },
  {
    name: 'Vegetarian Main Course',
    category: 'Vegetarian',
    price: null,
    description: 'A comforting vegetarian plate, made fresh to order.',
    image: 'dish-veg-main.jpg',
    tag: 'Popular Pick',
  },
  {
    name: 'Non-Vegetarian Main Course',
    category: 'Non-Vegetarian',
    price: null,
    description: 'Hearty and full of flavour, prepared fresh.',
    image: 'dish-nonveg-main.jpg',
    tag: "Chef's Special",
  },
  {
    name: 'Main Course Special',
    category: 'Main Course',
    price: null,
    description: 'One of our most-ordered main course dishes.',
    image: 'dish-main-course.jpg',
    tag: 'Popular Pick',
  },
  {
    name: 'Cold Drink / Beverage',
    category: 'Drinks',
    price: null,
    description: 'Ask your server for today\'s available drinks.',
    image: 'dish-drinks.jpg',
    tag: 'Popular Pick',
  },
]

// Dishes surfaced in the "Popular Dishes" section on the homepage.
export const popularDishSlugs = [
  'Chicken Biryani',
  "Chef's Special Chinese",
  'Chef\'s Special Indian Thali',
  'Grilled Special',
]
