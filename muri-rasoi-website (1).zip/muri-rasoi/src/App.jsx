import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import Features from './components/Features.jsx'
import PopularDishes from './components/PopularDishes.jsx'
import Menu from './components/Menu.jsx'
import About from './components/About.jsx'
import Gallery from './components/Gallery.jsx'
import Reviews from './components/Reviews.jsx'
import Location from './components/Location.jsx'
import Contact from './components/Contact.jsx'
import Footer from './components/Footer.jsx'

export default function App() {
  return (
    <div className="min-h-screen bg-aubergine-950">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <PopularDishes />
        <Menu />
        <About />
        <Gallery />
        <Reviews />
        <Location />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}
