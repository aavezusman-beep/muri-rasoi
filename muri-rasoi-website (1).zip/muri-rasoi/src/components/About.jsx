import Reveal from './Reveal.jsx'
import SmartImage from './SmartImage.jsx'

export default function About() {
  return (
    <section id="experience" className="bg-aubergine-900/40 py-20 md:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 md:px-8 lg:grid-cols-2 lg:gap-16">
        <Reveal className="order-2 lg:order-1">
          <h2 className="font-display text-3xl font-semibold leading-tight text-cream sm:text-4xl">
            More Than Just <span className="text-marigold-400">a Meal</span>
          </h2>
          <p className="mt-5 font-body text-base leading-relaxed text-cream/75 sm:text-lg">
            Step into Muri Rasoi for good food, warm lights and a relaxed place to enjoy your
            meal with family and friends.
          </p>
          <div className="mt-8 flex gap-8">
            <div>
              <p className="font-display text-3xl font-bold text-marigold-400">4.6</p>
              <p className="font-body text-sm text-cream/60">Google Rating</p>
            </div>
            <div>
              <p className="font-display text-3xl font-bold text-marigold-400">156</p>
              <p className="font-body text-sm text-cream/60">Google Reviews</p>
            </div>
          </div>
        </Reveal>

        <Reveal className="order-1 lg:order-2" delay={100}>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2 aspect-[16/10] overflow-hidden rounded-2xl">
              <SmartImage
                src="/images/interior-main.jpg"
                alt="Muri Rasoi dining area"
                className="h-full w-full object-cover"
                label="Add photo: interior-main.jpg"
              />
            </div>
            <div className="aspect-square overflow-hidden rounded-2xl">
              <SmartImage
                src="/images/interior-lighting.jpg"
                alt="Warm ambient lighting at Muri Rasoi"
                className="h-full w-full object-cover"
                label="interior-lighting.jpg"
              />
            </div>
            <div className="aspect-square overflow-hidden rounded-2xl">
              <SmartImage
                src="/images/interior-wall.jpg"
                alt="Brick wall interior detail at Muri Rasoi"
                className="h-full w-full object-cover"
                label="interior-wall.jpg"
              />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
