import { useState } from 'react'
import Reveal from './Reveal.jsx'
import SmartImage from './SmartImage.jsx'
import { categories, menuItems } from '../data/menu.js'

export default function Menu() {
  const [active, setActive] = useState('All')
  const tabs = ['All', ...categories]

  const items =
    active === 'All' ? menuItems : menuItems.filter((item) => item.category === active)

  return (
    <section id="menu" className="bg-aubergine-950 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="text-center">
          <h2 className="font-display text-3xl font-semibold text-cream sm:text-4xl">Our Menu</h2>
          <p className="mx-auto mt-3 max-w-md font-body text-sm text-cream/65 sm:text-base">
            Indian and Chinese favourites, vegetarian and non-vegetarian, all made fresh.
          </p>
        </Reveal>

        {/* Category tabs */}
        <div
          className="mt-10 flex gap-2 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          role="tablist"
          aria-label="Menu categories"
        >
          {tabs.map((tab) => (
            <button
              key={tab}
              type="button"
              role="tab"
              aria-selected={active === tab}
              onClick={() => setActive(tab)}
              className={`shrink-0 rounded-full border px-5 py-2 font-body text-sm font-medium transition-colors ${
                active === tab
                  ? 'border-marigold-400 bg-marigold-400 text-aubergine-950'
                  : 'border-white/15 text-cream/75 hover:border-marigold-400/50'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Items */}
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item, i) => (
            <Reveal key={item.name + item.category} delay={(i % 6) * 60}>
              <div className="zoom-on-hover flex gap-4 rounded-2xl border border-white/10 bg-aubergine-900/50 p-4">
                <div className="h-24 w-24 shrink-0 overflow-hidden rounded-xl">
                  <SmartImage
                    src={`/images/${item.image}`}
                    alt={item.name}
                    className="h-full w-full object-cover"
                    label={item.image.replace(/\.[a-z]+$/, '')}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-display text-lg font-semibold leading-tight text-cream">
                      {item.name}
                    </h3>
                    {item.price ? (
                      <span className="shrink-0 font-body text-sm font-semibold text-marigold-400">
                        ₹{item.price}
                      </span>
                    ) : (
                      <span className="shrink-0 font-body text-xs text-cream/50">
                        Ask server
                      </span>
                    )}
                  </div>
                  <span className="mt-1 inline-block font-body text-[11px] font-medium text-magenta-400">
                    {item.category}
                  </span>
                  <p className="mt-1 font-body text-sm leading-snug text-cream/65">
                    {item.description}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {items.length === 0 && (
          <p className="mt-10 text-center font-body text-cream/60">
            More items coming soon in this category.
          </p>
        )}
      </div>
    </section>
  )
}
