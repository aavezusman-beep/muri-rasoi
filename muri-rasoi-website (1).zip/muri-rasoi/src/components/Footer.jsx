const quickLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Menu', href: '#menu' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Location', href: '#location' },
]

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-aubergine-950 py-14">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="font-display text-xl font-semibold text-cream">Muri Rasoi</p>
            <p className="mt-1 font-body text-sm italic text-marigold-300">
              Everyone's Favourite
            </p>
          </div>

          <div>
            <p className="font-body text-sm font-semibold text-cream">Address</p>
            <p className="mt-2 font-body text-sm leading-relaxed text-cream/65">
              Sahu Complex, More, near Factory,
              <br />
              P. O, Chota, Muri, Jharkhand 835101
            </p>
          </div>

          <div>
            <p className="font-body text-sm font-semibold text-cream">Contact</p>
            <p className="mt-2 font-body text-sm text-cream/65">
              <a href="tel:+918709861778" className="hover:text-marigold-300">
                087098 61778
              </a>
            </p>
            <p className="mt-1 font-body text-sm text-cream/65">
              WhatsApp:{' '}
              <a
                href="https://wa.me/917545929143"
                className="hover:text-marigold-300"
                target="_blank"
                rel="noopener noreferrer"
              >
                75459 29143
              </a>
            </p>
            <p className="mt-3 font-body text-sm text-cream/65">8:00 AM – 11:00 PM</p>
          </div>

          <div>
            <p className="font-body text-sm font-semibold text-cream">Quick Links</p>
            <ul className="mt-2 space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="font-body text-sm text-cream/65 hover:text-marigold-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6">
          <p className="font-body text-xs text-cream/45">
            © 2026 Muri Rasoi. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
