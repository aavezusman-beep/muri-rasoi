import { Star, Quote } from 'lucide-react'
import Reveal from './Reveal.jsx'

const reviews = [
  'Best place to order food around this area and service is excellent',
  'I never expected the quality and brilliant chicken biryani in a small town.',
  'Definitely recommend Best Chinese and Indian Items in this Restaurant.',
]

export default function Reviews() {
  return (
    <section id="reviews" className="bg-aubergine-900/40 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="text-center">
          <h2 className="font-display text-3xl font-semibold text-cream sm:text-4xl">
            What Customers Say
          </h2>
          <div className="mt-5 flex flex-col items-center gap-2">
            <span className="font-display text-4xl font-bold text-marigold-400">4.6</span>
            <div className="flex text-marigold-400" aria-hidden="true">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={20} fill="currentColor" strokeWidth={0} />
              ))}
            </div>
            <span className="font-body text-sm text-cream/65">156 Google Reviews</span>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {reviews.map((quote, i) => (
            <Reveal key={i} delay={i * 90}>
              <div className="h-full rounded-2xl border border-white/10 bg-aubergine-950/60 p-7">
                <Quote className="text-marigold-400/70" size={26} aria-hidden="true" />
                <p className="mt-4 font-body text-sm leading-relaxed text-cream/85 sm:text-base">
                  "{quote}"
                </p>
                <p className="mt-5 font-body text-xs uppercase tracking-wide text-cream/45">
                  Google Review
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 text-center">
          <a
            href="https://maps.app.goo.gl/XPXxWSEYWesXm71V7"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block rounded-full border-2 border-marigold-400 px-8 py-3 font-body text-sm font-semibold text-cream transition-colors hover:bg-marigold-400 hover:text-aubergine-950"
          >
            View on Google
          </a>
        </Reveal>
      </div>
    </section>
  )
}
