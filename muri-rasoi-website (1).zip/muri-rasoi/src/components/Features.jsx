import { UtensilsCrossed, Flame, Users, Star } from 'lucide-react'
import Reveal from './Reveal.jsx'

const features = [
  {
    icon: UtensilsCrossed,
    title: 'Variety on Every Plate',
    text: 'Indian, Chinese and more, all under one roof.',
  },
  {
    icon: Flame,
    title: 'Made for Food Lovers',
    text: 'Freshly prepared dishes packed with flavour.',
  },
  {
    icon: Users,
    title: 'Family Friendly',
    text: 'A comfortable place to enjoy meals together.',
  },
  {
    icon: Star,
    title: '4.6 Rated',
    text: 'Loved by customers across Muri.',
  },
]

export default function Features() {
  return (
    <section className="relative bg-aubergine-950 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <h2 className="max-w-xl font-display text-3xl font-semibold text-cream sm:text-4xl">
            Why <span className="neon-underline text-marigold-400">Muri Rasoi</span>
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 80}>
              <div className="h-full rounded-2xl border border-white/10 bg-aubergine-900/60 p-7 transition-colors hover:border-marigold-400/40">
                <f.icon className="text-marigold-400" size={30} strokeWidth={1.75} aria-hidden="true" />
                <h3 className="mt-5 font-display text-xl font-semibold text-cream">{f.title}</h3>
                <p className="mt-2 font-body text-sm leading-relaxed text-cream/70">{f.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
