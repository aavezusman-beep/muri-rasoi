import Reveal from './Reveal.jsx'
import SmartImage from './SmartImage.jsx'
import { menuItems, popularDishSlugs } from '../data/menu.js'

export default function PopularDishes() {
  const dishes = popularDishSlugs
    .map((name) => menuItems.find((item) => item.name === name))
    .filter(Boolean)

  return (
    <section className="bg-aubergine-900/40 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <h2 className="font-display text-3xl font-semibold text-cream sm:text-4xl">
            Popular <span className="text-marigold-400">Dishes</span>
          </h2>
          <a
            href="#menu"
            className="font-body text-sm font-medium text-marigold-300 underline-offset-4 hover:underline"
          >
            View Full Menu
          </a>
        </Reveal>

        <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
          {dishes.map((dish, i) => (
            <Reveal key={dish.name} delay={i * 70}>
              <div className="zoom-on-hover group overflow-hidden rounded-2xl border border-white/10 bg-aubergine-950">
                <div className="aspect-[4/5] w-full">
                  <SmartImage
                    src={`/images/${dish.image}`}
                    alt={dish.name}
                    className="h-full w-full object-cover"
                    label={dish.image.replace(/\.[a-z]+$/, '')}
                  />
                </div>
                <div className="p-4">
                  <span className="font-body text-[11px] font-medium text-marigold-400">
                    {dish.tag}
                  </span>
                  <h3 className="mt-1 font-display text-base font-semibold leading-tight text-cream sm:text-lg">
                    {dish.name}
                  </h3>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
