import { useEffect, useState } from 'react'
import { Menu, X, Phone } from 'lucide-react'
import SmartImage from './SmartImage.jsx'

const links = [
  { label: 'Home', href: '#home' },
  { label: 'Menu', href: '#menu' },
  { label: 'About', href: '#experience' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Location', href: '#location' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    // lock body scroll while mobile menu is open
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-aubergine-950/95 backdrop-blur shadow-glow-magenta py-2'
          : 'bg-gradient-to-b from-aubergine-950/90 to-transparent py-4'
      }`}
    >
      <nav
        className="mx-auto flex max-w-7xl items-center justify-between px-5 md:px-8"
        aria-label="Primary"
      >
        <a href="#home" className="flex items-center gap-3 shrink-0">
          <SmartImage
            src="/images/muri-rasoi-logo.png"
            alt="Muri Rasoi logo"
            className={`w-auto rounded-full object-cover transition-all duration-300 ${
              scrolled ? 'h-9' : 'h-12'
            }`}
            label="Logo"
          />
          <span className="font-display text-lg font-semibold tracking-tight text-cream sm:text-xl">
            Muri Rasoi
          </span>
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="font-body text-sm text-cream/85 transition-colors hover:text-marigold-400"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden md:block">
          <a
            href="#menu"
            className="rounded-full bg-gradient-to-r from-ember-500 to-magenta-500 px-6 py-2.5 font-body text-sm font-semibold text-cream shadow-glow transition-transform hover:scale-105"
          >
            Order Now
          </a>
        </div>

        <button
          type="button"
          className="rounded-md p-2 text-cream md:hidden"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        className={`md:hidden overflow-hidden transition-[max-height] duration-300 ease-in-out ${
          open ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <ul className="flex flex-col gap-1 bg-aubergine-950/98 px-6 pb-6 pt-2">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setOpen(false)}
                className="block py-3 font-body text-base text-cream/90 border-b border-white/5"
              >
                {link.label}
              </a>
            </li>
          ))}
          <li className="pt-4 flex gap-3">
            <a
              href="tel:+918709861778"
              className="flex flex-1 items-center justify-center gap-2 rounded-full border border-marigold-400/60 px-4 py-3 text-sm text-cream"
            >
              <Phone size={16} /> Call
            </a>
            <a
              href="#menu"
              onClick={() => setOpen(false)}
              className="flex-1 rounded-full bg-gradient-to-r from-ember-500 to-magenta-500 px-4 py-3 text-center text-sm font-semibold text-cream"
            >
              Order Now
            </a>
          </li>
        </ul>
      </div>
    </header>
  )
}
