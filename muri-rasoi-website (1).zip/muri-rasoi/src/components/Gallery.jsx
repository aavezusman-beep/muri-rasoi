import { useCallback, useEffect, useState } from 'react'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'
import Reveal from './Reveal.jsx'
import SmartImage from './SmartImage.jsx'

const photos = [
  { src: 'gallery-1.jpg', alt: 'Muri Rasoi restaurant ambience' },
  { src: 'muri-rasoi-logo.png', alt: 'Muri Rasoi logo' },
  { src: 'gallery-2.jpg', alt: 'Dish served at Muri Rasoi' },
  { src: 'gallery-3.jpg', alt: 'Interior seating at Muri Rasoi' },
  { src: 'gallery-4.jpg', alt: 'Warm lighting inside Muri Rasoi' },
  { src: 'gallery-5.jpg', alt: 'Food photograph from Muri Rasoi menu' },
  { src: 'gallery-6.jpg', alt: 'Brick wall detail at Muri Rasoi' },
  { src: 'gallery-7.jpg', alt: 'Muri Rasoi dining area' },
]

export default function Gallery() {
  const [activeIndex, setActiveIndex] = useState(null)
  const isOpen = activeIndex !== null

  const close = useCallback(() => setActiveIndex(null), [])
  const prev = useCallback(
    () => setActiveIndex((i) => (i - 1 + photos.length) % photos.length),
    [],
  )
  const next = useCallback(() => setActiveIndex((i) => (i + 1) % photos.length), [])

  useEffect(() => {
    if (!isOpen) return
    document.body.style.overflow = 'hidden'
    const onKey = (e) => {
      if (e.key === 'Escape') close()
      if (e.key === 'ArrowLeft') prev()
      if (e.key === 'ArrowRight') next()
    }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [isOpen, close, prev, next])

  return (
    <section id="gallery" className="bg-aubergine-950 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <h2 className="font-display text-3xl font-semibold text-cream sm:text-4xl">Gallery</h2>
          <p className="mt-3 font-body text-sm text-cream/65 sm:text-base">
            A look inside Muri Rasoi.
          </p>
        </Reveal>

        <div className="mt-10 columns-2 gap-4 sm:columns-3 lg:columns-4 [column-fill:balance]">
          {photos.map((photo, i) => (
            <button
              key={photo.src}
              type="button"
              onClick={() => setActiveIndex(i)}
              className="zoom-on-hover mb-4 block w-full overflow-hidden rounded-2xl border border-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-marigold-400"
              aria-label={`Open photo: ${photo.alt}`}
            >
              <SmartImage
                src={`/images/${photo.src}`}
                alt={photo.alt}
                className="w-full object-cover"
                style={{ aspectRatio: i % 3 === 0 ? '3/4' : '4/5' }}
                label={photo.src.replace(/\.[a-z]+$/, '')}
              />
            </button>
          ))}
        </div>
      </div>

      {isOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Photo viewer"
        >
          <button
            type="button"
            onClick={close}
            className="absolute right-5 top-5 rounded-full bg-white/10 p-2 text-cream hover:bg-white/20"
            aria-label="Close photo viewer"
          >
            <X size={24} />
          </button>

          <button
            type="button"
            onClick={prev}
            className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-cream hover:bg-white/20 sm:left-6"
            aria-label="Previous photo"
          >
            <ChevronLeft size={26} />
          </button>

          <div className="max-h-[80vh] max-w-3xl">
            <SmartImage
              src={`/images/${photos[activeIndex].src}`}
              alt={photos[activeIndex].alt}
              className="max-h-[80vh] w-full rounded-xl object-contain"
              label={photos[activeIndex].src.replace(/\.[a-z]+$/, '')}
            />
            <p className="mt-3 text-center font-body text-sm text-cream/70">
              {photos[activeIndex].alt}
            </p>
          </div>

          <button
            type="button"
            onClick={next}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-cream hover:bg-white/20 sm:right-6"
            aria-label="Next photo"
          >
            <ChevronRight size={26} />
          </button>
        </div>
      )}
    </section>
  )
}
