import { useState } from 'react'
import { ImageOff } from 'lucide-react'

/**
 * Tries to load the real photo from /public/images/<src>.
 * If it 404s (photo not supplied yet), falls back to a clearly-marked
 * placeholder block in the brand palette instead of a fake stock photo.
 * Once you drop the real file into public/images/ with the same name,
 * this automatically starts showing it — no code changes needed.
 */
export default function SmartImage({ src, alt, className = '', label, style, ...rest }) {
  const [failed, setFailed] = useState(false)

  if (failed) {
    return (
      <div
        className={`photo-placeholder ${className}`}
        style={style}
        role="img"
        aria-label={alt}
      >
        <div className="relative z-10 flex flex-col items-center gap-2 px-4 text-center text-cream/60">
          <ImageOff size={28} strokeWidth={1.5} aria-hidden="true" />
          <span className="font-body text-xs tracking-wide">
            {label || 'Add photo: ' + src.split('/').pop()}
          </span>
        </div>
      </div>
    )
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      onError={() => setFailed(true)}
      className={className}
      style={style}
      {...rest}
    />
  )
}
