import { Phone, MapPin, Clock, MessageCircle } from 'lucide-react'
import Reveal from './Reveal.jsx'

export default function Location() {
  return (
    <section id="location" className="bg-aubergine-950 py-20 md:py-28">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:px-8 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <h2 className="font-display text-3xl font-semibold text-cream sm:text-4xl">
            Find <span className="text-marigold-400">Muri Rasoi</span>
          </h2>

          <div className="mt-8 space-y-6">
            <div className="flex gap-4">
              <MapPin className="mt-1 shrink-0 text-marigold-400" size={22} />
              <div>
                <p className="font-body text-sm font-semibold text-cream">Address</p>
                <p className="mt-1 font-body text-sm leading-relaxed text-cream/70">
                  Sahu Complex, More, near Factory, P. O, Chota,
                  <br />
                  Muri, Jharkhand 835101
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <Clock className="mt-1 shrink-0 text-marigold-400" size={22} />
              <div>
                <p className="font-body text-sm font-semibold text-cream">Opening Hours</p>
                <p className="mt-1 font-body text-sm text-cream/70">8:00 AM – 11:00 PM, daily</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Phone className="mt-1 shrink-0 text-marigold-400" size={22} />
              <div>
                <p className="font-body text-sm font-semibold text-cream">Phone</p>
                <a
                  href="tel:+918709861778"
                  className="mt-1 inline-block font-body text-sm text-cream/70 hover:text-marigold-300"
                >
                  087098 61778
                </a>
              </div>
            </div>
          </div>

          <div className="mt-9 flex flex-wrap gap-3">
            <a
              href="tel:+918709861778"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-ember-500 to-magenta-500 px-6 py-3 font-body text-sm font-semibold text-cream shadow-glow-magenta"
            >
              <Phone size={16} /> Call Now
            </a>
            <a
              href="https://maps.app.goo.gl/XPXxWSEYWesXm71V7"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border-2 border-marigold-400 px-6 py-3 font-body text-sm font-semibold text-cream hover:bg-marigold-400 hover:text-aubergine-950"
            >
              <MapPin size={16} /> Get Directions
            </a>
            <a
              href="https://wa.me/917545929143"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border-2 border-emerald-500 px-6 py-3 font-body text-sm font-semibold text-cream hover:bg-emerald-500/20"
            >
              <MessageCircle size={16} /> WhatsApp
            </a>
          </div>

          <p className="mt-4 font-body text-xs text-cream/50">
            Second contact number:{' '}
            <a href="tel:+919835548224" className="underline hover:text-marigold-300">
              98355 48224
            </a>
          </p>
        </Reveal>

        <Reveal delay={100}>
          <div className="overflow-hidden rounded-2xl border border-white/10 shadow-glow">
            <iframe
              title="Muri Rasoi location map"
              src="https://www.google.com/maps?q=Sahu+Complex,+More,+near+Factory,+Chota,+Muri,+Jharkhand+835101&output=embed"
              className="h-[380px] w-full lg:h-full"
              style={{ border: 0, minHeight: 380 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </Reveal>
      </div>
    </section>
  )
}
