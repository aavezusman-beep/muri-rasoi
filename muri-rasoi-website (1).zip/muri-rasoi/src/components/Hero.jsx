import { Star, MapPin } from 'lucide-react'
import SmartImage from './SmartImage.jsx'

export default function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-[92vh] items-center overflow-hidden bg-aubergine-950 pt-24"
    >
      {/* Background photo layer */}
      <div className="absolute inset-0">
        <SmartImage
          src="/images/hero-restaurant.jpg"
          alt="Muri Rasoi restaurant interior with warm ambient lighting"
          className="h-full w-full object-cover"
          label="Add hero photo: hero-restaurant.jpg"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-aubergine-950 via-aubergine-950/70 to-aubergine-950/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-aubergine-950/90 via-transparent to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-5 md:px-8">
        <div className="max-w-2xl">
          <p className="font-body text-sm font-medium uppercase tracking-[0.2em] text-marigold-400">
            Muri, Jharkhand
          </p>

          <h1 className="mt-4 font-display text-5xl font-bold leading-[1.05] text-cream sm:text-6xl md:text-7xl">
            Muri Rasoi
          </h1>

          <p className="mt-4 font-display text-2xl italic text-marigold-300 sm:text-3xl">
            Everyone's Favourite
          </p>

          <p className="mt-5 max-w-lg font-body text-base text-cream/80 sm:text-lg">
            Good food. Great company. Memorable moments.
          </p>

          <div className="mt-6 flex items-center gap-3">
            <div className="flex text-marigold-400" aria-hidden="true">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={20} fill="currentColor" strokeWidth={0} />
              ))}
            </div>
            <span className="font-body text-sm text-cream/85">
              4.6 Google Rating &bull; 156 Reviews
            </span>
          </div>

          <div className="mt-9 flex flex-wrap gap-4">
            <a
              href="#menu"
              className="rounded-full bg-gradient-to-r from-ember-500 to-magenta-500 px-8 py-3.5 font-body text-base font-semibold text-cream shadow-glow-magenta transition-transform hover:scale-105"
            >
              Explore Menu
            </a>
            <a
              href="tel:+918709861778"
              className="rounded-full border-2 border-marigold-400 px-8 py-3.5 font-body text-base font-semibold text-cream transition-colors hover:bg-marigold-400 hover:text-aubergine-950"
            >
              Order Now
            </a>
          </div>

          <a
            href="https://maps.app.goo.gl/XPXxWSEYWesXm71V7"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex items-center gap-2 font-body text-sm text-cream/75 underline-offset-4 transition-colors hover:text-marigold-300 hover:underline"
          >
            <MapPin size={16} />
            Get Directions
          </a>
        </div>
      </div>
    </section>
  )
}
