import { Phone, MapPin } from 'lucide-react'
import Reveal from './Reveal.jsx'

export default function Contact() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-aubergine-950 via-[#3A0F2E] to-ember-600 py-24 md:py-32">
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          background:
            'radial-gradient(circle at 20% 30%, rgba(232,147,42,0.25), transparent 45%), radial-gradient(circle at 80% 70%, rgba(196,37,105,0.3), transparent 50%)',
        }}
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-3xl px-5 text-center md:px-8">
        <Reveal>
          <h2 className="font-display text-4xl font-bold text-cream sm:text-5xl">Hungry Yet?</h2>
          <p className="mt-4 font-body text-lg text-cream/80">
            Your next favourite meal is waiting.
          </p>

          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <a
              href="#menu"
              className="rounded-full bg-cream px-8 py-3.5 font-body text-base font-semibold text-aubergine-950 shadow-glow transition-transform hover:scale-105"
            >
              Order Now
            </a>
            <a
              href="tel:+918709861778"
              className="inline-flex items-center gap-2 rounded-full border-2 border-cream/70 px-8 py-3.5 font-body text-base font-semibold text-cream transition-colors hover:bg-cream/10"
            >
              <Phone size={18} /> Call Muri Rasoi
            </a>
            <a
              href="https://maps.app.goo.gl/XPXxWSEYWesXm71V7"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border-2 border-cream/70 px-8 py-3.5 font-body text-base font-semibold text-cream transition-colors hover:bg-cream/10"
            >
              <MapPin size={18} /> Get Directions
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
