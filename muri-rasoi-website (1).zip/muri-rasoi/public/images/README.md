# Drop your photos here

No images came through with the original brief, so the site currently shows
branded placeholder blocks wherever a photo belongs. Add files with these
**exact names** to `public/images/` and they'll appear automatically —
no code changes needed.

| Filename                     | Used for                                    |
|-------------------------------|----------------------------------------------|
| `muri-rasoi-logo.png`          | Navbar logo + footer + gallery               |
| `hero-restaurant.jpg`          | Hero background photo                        |
| `interior-main.jpg`            | Restaurant Experience section (large photo)  |
| `interior-lighting.jpg`        | Restaurant Experience section (small photo)  |
| `interior-wall.jpg`            | Restaurant Experience section (small photo)  |
| `gallery-1.jpg` … `gallery-7.jpg` | Gallery masonry grid                      |
| `dish-chicken-biryani.jpg`     | Popular Dishes + Menu                        |
| `dish-chinese-special.jpg`     | Popular Dishes + Menu                        |
| `dish-indian-thali.jpg`        | Popular Dishes + Menu                        |
| `dish-grilled-special.jpg`     | Popular Dishes + Menu                        |
| `dish-veg-main.jpg`            | Menu                                         |
| `dish-nonveg-main.jpg`         | Menu                                         |
| `dish-main-course.jpg`         | Menu                                         |
| `dish-drinks.jpg`              | Menu                                         |

Tips:
- Use real Muri Rasoi photos only — the brief asks that stock food photos
  not be implied as photos taken in-house.
- JPGs around 1600px on the long edge are plenty; the site lazy-loads and
  scales them with `object-fit: cover`.
- To add more menu items or real prices, edit `src/data/menu.js` — it's a
  plain array, safe to extend.
- To add more gallery photos, edit the `photos` array at the top of
  `src/components/Gallery.jsx`.
